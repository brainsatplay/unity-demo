This Applet implements basic two way communication between an integrated Unity WebGL build and the B@P library API.


## Choices Made
Everything you want included must be flat in the `/app` directory to be read as a .zip file.
