import {settings} from './app/settings.js'
let app =  new brainsatplay.App(settings)
app.init()